# Software Architecture Documentation
# Fatigue Tester Data Acquisition System

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                          USER INTERFACE LAYER                        │
│                        (main_application.py)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │  Connection  │  │   Logging    │  │     Plot     │             │
│  │   Controls   │  │   Controls   │  │   Settings   │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│  ┌────────────────────────────────────────────────────┐             │
│  │           Statistics & Status Display              │             │
│  └────────────────────────────────────────────────────┘             │
└─────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      ORCHESTRATION LAYER                             │
│                     (Main Application GUI)                           │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐    │
│  │  Watchdog Timer │  │ Statistics      │  │  Event Manager  │    │
│  │  (5s timeout)   │  │ Collector       │  │                 │    │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
        │                           │                           │
        ▼                           ▼                           ▼
┌──────────────┐          ┌──────────────┐          ┌──────────────┐
│   PRODUCER   │          │   BROKER     │          │  CONSUMERS   │
│    LAYER     │──Queue──▶│   LAYER      │──Event──▶│    LAYER     │
└──────────────┘          └──────────────┘          └──────────────┘

## Detailed Component Architecture

### 1. HARDWARE ABSTRACTION LAYER (Producer)
┌─────────────────────────────────────────────────────────────┐
│                  serial_reader.py                            │
│  ┌─────────────────────────────────────────────────┐        │
│  │          SerialReader (Thread)                   │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  Serial Port Communication             │     │        │
│  │  │  - Connect/Disconnect                  │     │        │
│  │  │  - Read data continuously              │     │        │
│  │  │  - Handle errors                       │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  │               │                                  │        │
│  │               ▼                                  │        │
│  │      ┌──────────────────┐                       │        │
│  │      │   Data Queue     │                       │        │
│  │      │  (Thread-Safe)   │                       │        │
│  │      └──────────────────┘                       │        │
│  └─────────────────────────────────────────────────┘        │
│                                                              │
│  ┌─────────────────────────────────────────────────┐        │
│  │          MockSerialReader (Thread)               │        │
│  │  - Generates simulated test data                 │        │
│  │  - For testing without hardware                  │        │
│  └─────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────┘

### 2. DATA PROCESSING LAYER (Broker)
┌─────────────────────────────────────────────────────────────┐
│               data_parser.py                                 │
│  ┌─────────────────────────────────────────────────┐        │
│  │            DataParser                            │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  Parse Serial Data                     │     │        │
│  │  │  - Split by delimiters                 │     │        │
│  │  │  - Apply decimal conversions           │     │        │
│  │  │  - Create FatigueTestData objects      │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  │               │                                  │        │
│  │               ▼                                  │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  Validate Data                         │     │        │
│  │  │  - Range checks                        │     │        │
│  │  │  - Logic validation                    │     │        │
│  │  │  - Error code interpretation           │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  └─────────────────────────────────────────────────┘        │
│                                                              │
│  ┌─────────────────────────────────────────────────┐        │
│  │        DataProcessorWorker (Thread)              │        │
│  │  - Reads from queue                              │        │
│  │  - Parses and validates                          │        │
│  │  - Emits signals to consumers                    │        │
│  └─────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────┘

### 3. CONSUMER LAYER
┌─────────────────────────────────────────────────────────────┐
│              data_logger.py                                  │
│  ┌─────────────────────────────────────────────────┐        │
│  │            DataLogger                            │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  File Management                       │     │        │
│  │  │  - Timestamp-based naming              │     │        │
│  │  │  - No overwrite guarantee              │     │        │
│  │  │  - Automatic directory creation        │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  │               │                                  │        │
│  │               ▼                                  │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  CSV Writing                           │     │        │
│  │  │  - Write header                        │     │        │
│  │  │  - Append data rows                    │     │        │
│  │  │  - Buffer management                   │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  └─────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                      ┌──────────────┐
                      │ CSV Files    │
                      │ (./logs/)    │
                      └──────────────┘

┌─────────────────────────────────────────────────────────────┐
│              live_plotter.py                                 │
│  ┌─────────────────────────────────────────────────┐        │
│  │            LivePlotter                           │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  Data Buffering                        │     │        │
│  │  │  - Deque ring buffers                  │     │        │
│  │  │  - Automatic old data removal          │     │        │
│  │  │  - Configurable buffer size            │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  │               │                                  │        │
│  │               ▼                                  │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  Plot Updates (QTimer)                 │     │        │
│  │  │  - Decoupled from data rate            │     │        │
│  │  │  - Configurable update interval        │     │        │
│  │  │  - Auto-ranging                        │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  │               │                                  │        │
│  │               ▼                                  │        │
│  │  ┌────────────────────────────────────────┐     │        │
│  │  │  PyQtGraph Rendering                   │     │        │
│  │  │  - Forces plot                         │     │        │
│  │  │  - Positions plot                      │     │        │
│  │  │  - Travel plot                         │     │        │
│  │  └────────────────────────────────────────┘     │        │
│  └─────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────┘

### 4. CONFIGURATION LAYER
┌─────────────────────────────────────────────────────────────┐
│                  config.py                                   │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐  │
│  │ SerialConfig  │  │  PlotConfig   │  │  LogConfig    │  │
│  │ - port        │  │ - update_rate │  │ - filename    │  │
│  │ - baudrate    │  │ - max_points  │  │ - format      │  │
│  │ - timeout     │  │ - auto_range  │  │ - directory   │  │
│  └───────────────┘  └───────────────┘  └───────────────┘  │
│                                                              │
│  ┌─────────────────────────────────────────────────┐        │
│  │  Error Code Definitions                         │        │
│  │  - 000-999: Complete error code mapping         │        │
│  └─────────────────────────────────────────────────┘        │
│                                                              │
│  ┌─────────────────────────────────────────────────┐        │
│  │  Data Format Specification                      │        │
│  │  - Field definitions and order                  │        │
│  │  - Decimal place specifications                 │        │
│  └─────────────────────────────────────────────────┘        │
└─────────────────────────────────────────────────────────────┘

## Data Flow Diagram

Serial Port → SerialReader → Queue → DataProcessor → {Logger, Plotter}
                  │                       │              │       │
                  │                       │              │       │
              Raw Data              Parsed Data      CSV File  Display
            (String)              (FatigueTestData)


## Threading Model

┌────────────────┐
│   Main Thread  │  (GUI, User Input, Display Updates)
└────────────────┘
        │
        ├─────────────────────────────────────────┐
        │                                         │
┌────────────────┐                     ┌──────────────────┐
│ SerialReader   │                     │  DataProcessor   │
│    Thread      │──Queue─────────────▶│     Thread       │
└────────────────┘                     └──────────────────┘
                                                │
                                                │ Signals
                                                ▼
                                    ┌───────────────────────┐
                                    │    Main Thread        │
                                    │  (Logger & Plotter)   │
                                    └───────────────────────┘

## Safety & Reliability Features

1. **Watchdog Timer**
   - Monitors data reception
   - Alerts on timeout (5 seconds default)
   - Detects connection issues

2. **Queue Buffering**
   - Thread-safe communication
   - Prevents data loss during OS stalls
   - Decouples producer from consumers

3. **Error Handling**
   - Parse error tracking
   - Validation at multiple levels
   - Graceful degradation

4. **File Safety**
   - Timestamp-based naming
   - No overwrite guarantee
   - Automatic backup numbering

5. **Memory Management**
   - Ring buffers (deque)
   - Automatic old data removal
   - Configurable limits

## Extension Points

1. **Add New Plots**
   - Modify live_plotter.py
   - Add data buffer
   - Create plot widget
   - Add update logic

2. **Change Data Format**
   - Update config.py (DATA_FIELDS)
   - Modify data_parser.py (parse method)
   - Update FatigueTestData dataclass

3. **Add Export Formats**
   - Extend data_logger.py
   - Implement new writer methods
   - Add UI controls

4. **Remote Monitoring**
   - Add network layer
   - Implement data streaming
   - Create remote viewer

5. **Database Integration**
   - Replace/supplement CSV logger
   - Implement database connector
   - Add query interface

## Performance Considerations

1. **Data Rate**: Up to 10 Hz (0.1s intervals)
2. **Parse Speed**: >10,000 lines/second
3. **Plot Update**: Configurable, default 1 Hz
4. **Memory Usage**: ~100 MB typical
5. **Disk I/O**: Minimal, buffered writes

## Dependencies

- pyserial: Serial port communication
- PyQt5: GUI framework
- pyqtgraph: High-performance plotting
- pandas: Data manipulation
- numpy: Numerical operations
