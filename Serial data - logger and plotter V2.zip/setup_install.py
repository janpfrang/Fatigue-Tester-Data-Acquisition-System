"""
Installation and Setup Script
Fatigue Tester Data Acquisition System
"""

import sys
import subprocess
import os
from pathlib import Path


def check_python_version():
    """Check if Python version is adequate"""
    print("Checking Python version...")
    version = sys.version_info
    
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"ERROR: Python 3.8 or higher required. You have {version.major}.{version.minor}")
        return False
    
    print(f"✓ Python {version.major}.{version.minor}.{version.micro} detected")
    return True


def install_dependencies():
    """Install required Python packages"""
    print("\nInstalling dependencies...")
    
    packages = [
        'pyserial',
        'PyQt5',
        'pyqtgraph',
        'pandas',
        'numpy'
    ]
    
    for package in packages:
        print(f"Installing {package}...")
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])
            print(f"✓ {package} installed")
        except subprocess.CalledProcessError:
            print(f"✗ Failed to install {package}")
            return False
    
    return True


def create_directories():
    """Create necessary directories"""
    print("\nCreating directories...")
    
    directories = [
        'logs',
    ]
    
    for directory in directories:
        path = Path(directory)
        path.mkdir(exist_ok=True)
        print(f"✓ Created {directory}/")
    
    return True


def verify_files():
    """Verify all required files are present"""
    print("\nVerifying files...")
    
    required_files = [
        'main_application.py',
        'config.py',
        'data_parser.py',
        'serial_reader.py',
        'data_logger.py',
        'live_plotter.py',
        'requirements.txt',
        'README.md'
    ]
    
    all_present = True
    for filename in required_files:
        if Path(filename).exists():
            print(f"✓ {filename}")
        else:
            print(f"✗ {filename} MISSING")
            all_present = False
    
    return all_present


def create_launch_script():
    """Create a convenient launch script"""
    print("\nCreating launch script...")
    
    # Windows batch file
    if sys.platform == 'win32':
        script_content = """@echo off
echo Starting Fatigue Tester Data Acquisition System...
python main_application.py
pause
"""
        with open('launch.bat', 'w') as f:
            f.write(script_content)
        print("✓ Created launch.bat")
    
    # Linux/Mac shell script
    else:
        script_content = """#!/bin/bash
echo "Starting Fatigue Tester Data Acquisition System..."
python3 main_application.py
"""
        with open('launch.sh', 'w') as f:
            f.write(script_content)
        
        # Make executable
        os.chmod('launch.sh', 0o755)
        print("✓ Created launch.sh")


def test_imports():
    """Test if all imports work"""
    print("\nTesting imports...")
    
    test_cases = [
        ('serial', 'pyserial'),
        ('PyQt5.QtWidgets', 'PyQt5'),
        ('pyqtgraph', 'pyqtgraph'),
        ('pandas', 'pandas'),
        ('numpy', 'numpy')
    ]
    
    all_ok = True
    for module, package in test_cases:
        try:
            __import__(module)
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} - Import failed")
            all_ok = False
    
    return all_ok


def print_next_steps():
    """Print instructions for next steps"""
    print("\n" + "=" * 60)
    print("INSTALLATION COMPLETE!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Read QUICKSTART.txt for basic usage")
    print("2. Read README.md for detailed documentation")
    print("3. Test with mock data first:")
    if sys.platform == 'win32':
        print("   - Double-click launch.bat")
    else:
        print("   - Run ./launch.sh or python3 main_application.py")
    print("   - Check 'Use Mock Data (Testing)'")
    print("   - Click 'Connect'")
    print("\n4. Connect to real hardware:")
    print("   - Find your COM port")
    print("   - Select port and baudrate")
    print("   - Click 'Connect'")
    print("\n" + "=" * 60)


def main():
    """Main installation routine"""
    print("=" * 60)
    print("FATIGUE TESTER DATA ACQUISITION SYSTEM")
    print("Installation Script")
    print("=" * 60 + "\n")
    
    # Check Python version
    if not check_python_version():
        print("\nPlease install Python 3.8 or higher and try again.")
        sys.exit(1)
    
    # Verify files
    if not verify_files():
        print("\nERROR: Some required files are missing!")
        print("Please ensure all files are in the same directory.")
        sys.exit(1)
    
    # Install dependencies
    try:
        print("\nDo you want to install dependencies? (y/n): ", end='')
        response = input().lower()
        
        if response == 'y':
            if not install_dependencies():
                print("\nERROR: Failed to install dependencies!")
                sys.exit(1)
    except KeyboardInterrupt:
        print("\n\nInstallation cancelled.")
        sys.exit(0)
    
    # Create directories
    create_directories()
    
    # Test imports
    if not test_imports():
        print("\nWARNING: Some imports failed!")
        print("You may need to install dependencies manually:")
        print("  pip install -r requirements.txt")
    
    # Create launch script
    create_launch_script()
    
    # Print next steps
    print_next_steps()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInstallation cancelled.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nERROR: {e}")
        sys.exit(1)
