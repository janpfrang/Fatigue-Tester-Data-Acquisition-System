# Fatigue Tester Data Acquisition System

A professional-grade data acquisition system for fatigue testing equipment with real-time visualization and data logging capabilities.

## Features

- **Real-time Serial Data Acquisition**: Continuously receives and processes test data from fatigue testing equipment
- **Live Plotting**: Real-time visualization of forces, positions, and travel measurements
- **Data Logging**: Automatic CSV logging with timestamp-based file naming (no overwrites)
- **Error Detection**: Built-in error code recognition and alerting system
- **Watchdog Timer**: Monitors data flow and alerts on connection issues
- **Mock Mode**: Built-in data generator for testing without hardware
- **Thread-Safe Architecture**: Implements producer-consumer pattern for reliable operation

## Architecture

The system follows a **Layered, Event-Driven Architecture** using the **Producer-Consumer pattern**:

### 1. Hardware Abstraction Layer (Producer)
- `serial_reader.py`: Isolates serial communication logic
- Runs in separate thread to prevent GUI blocking
- Includes mock reader for development/testing

### 2. Data Processing Layer (Broker)
- `data_parser.py`: Parses and validates incoming data
- Converts raw serial strings to structured data objects
- Implements data validation rules

### 3. Consumer Layer
- `data_logger.py`: Handles CSV file I/O operations
- `live_plotter.py`: Manages real-time visualization with decoupled update rate

### 4. Orchestration Layer
- `main_application.py`: PyQt5 GUI that coordinates all components
- Implements watchdog timer for connection monitoring
- Provides user controls and statistics display

### 5. Configuration Layer
- `config.py`: Centralized configuration management
- Contains error codes and data field definitions

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup

1. Clone or download this repository

2. Install required packages:
```bash
pip install -r requirements.txt
```

Or install manually:
```bash
pip install pyserial PyQt5 pyqtgraph pandas numpy
```

## Usage

### Starting the Application

```bash
python main_application.py
```

### Connecting to Hardware

1. **Select COM Port**: Choose the appropriate COM port from the dropdown
2. **Set Baudrate**: Select the correct baudrate (default: 9600)
3. **Click Connect**: Establishes connection and starts logging

### Testing Without Hardware

1. Check **"Use Mock Data (Testing)"** checkbox
2. Click **Connect**
3. The system will generate realistic test data automatically

### Data Logging

- Logging starts automatically upon connection
- Files are saved in `./logs/` directory
- Format: `fatigue_test_YYYYMMDD_HHMMSS.csv`
- Use **"Save Log As..."** to save with custom name
- Use **"Start New Log"** to begin a new log file

### Plot Controls

- **Update Interval**: Adjust plot refresh rate (100-5000ms)
- **Auto Range**: Enable/disable automatic axis scaling
- **Clear Plots**: Clear all plotted data (does not affect logged data)

## Data Format

The system expects serial data in the following format:

```
DTA;31422;182;263;0;793;2238;0;611;0;!
```

### Field Descriptions

1. **Status** (DTA/END): Test running or ended
2. **Cycles**: Number of test cycles
3. **Position 0** (×0.01 mm): Initial position
4. **Lower Force** (×0.1 N): Lower force measurement
5. **Travel Lower** (×0.01 mm): Additional travel to reach lower force
6. **Position Upper** (×0.01 mm): Position at upper force
7. **Upper Force** (×0.1 N): Upper force measurement
8. **Travel Upper** (×0.01 mm): Additional travel to reach upper force
9. **Travel at Upper** (×0.01 mm): Total travel at upper force
10. **Error Code**: Error/status code (see Error Codes section)
11. **!**: End-of-line marker

## Error Codes

| Code | Description |
|------|-------------|
| 000 | No Error: Everything is OK |
| 010 | Test failed: Completed with error |
| 011 | Additional Path 1 Violation |
| 012 | Additional Path 2 Violation |
| 013-014 | Force Limit 2 Violations |
| 101-107 | Motor Errors |
| 201-205 | Travel/Force Search Errors |

Full error descriptions are displayed in the status log when detected.

## Configuration

### Serial Port Settings

Edit `config.py` to change default serial parameters:

```python
@dataclass
class SerialConfig:
    port: str = "COM3"
    baudrate: int = 9600
    timeout: float = 1.0
    bytesize: int = 8
    parity: str = 'N'
    stopbits: int = 1
```

### Plot Settings

Adjust plotting behavior:

```python
@dataclass
class PlotConfig:
    update_interval_ms: int = 1000  # Update every 1 second
    max_points_display: int = 1000   # Maximum points to show
    auto_range: bool = True
```

### Watchdog Timeout

Configure data reception monitoring:

```python
@dataclass
class WatchdogConfig:
    timeout_seconds: float = 5.0  # Alert if no data for 5 seconds
```

## File Structure

```
├── main_application.py    # Main GUI application
├── config.py             # Configuration settings
├── data_parser.py        # Data parsing and validation
├── serial_reader.py      # Serial communication (Producer)
├── data_logger.py        # CSV logging (Consumer)
├── live_plotter.py       # Real-time plotting (Consumer)
├── requirements.txt      # Python dependencies
├── README.md            # This file
└── logs/                # Directory for CSV log files (created automatically)
```

## CSV Output Format

The logged CSV files contain the following columns:

- Timestamp
- Status
- Cycles
- Position_0_mm
- Force_Lower_N
- Travel_Lower_mm
- Position_Upper_mm
- Force_Upper_N
- Travel_Upper_mm
- Travel_at_Upper_mm
- Error_Code
- Error_Description
- Raw_Data

## Troubleshooting

### Connection Issues

1. **COM port not found**: Verify the correct port name in Device Manager (Windows) or `/dev/tty*` (Linux)
2. **Permission denied** (Linux): Add user to dialout group: `sudo usermod -a -G dialout $USER`
3. **Baudrate mismatch**: Ensure baudrate matches the testing equipment

### Data Issues

1. **Parse errors**: Check that data format matches expected format
2. **Watchdog timeouts**: Verify equipment is transmitting data regularly
3. **Validation errors**: Review data ranges in `data_parser.py`

### Performance Issues

1. **Slow plotting**: Increase plot update interval
2. **High CPU usage**: Reduce max_points_display in plot configuration
3. **Disk space**: Monitor logs directory size

## Development

### Adding New Plots

Edit `live_plotter.py` and add new plot in `setup_plots()`:

```python
self.plots['my_plot'] = self.plot_widget.addPlot(row=3, col=0, title="My Plot")
self.curves['my_curve'] = self.plots['my_plot'].plot(pen=pg.mkPen(color='r', width=2))
```

### Modifying Data Fields

1. Update `DATA_FIELDS` in `config.py`
2. Modify parsing logic in `data_parser.py`
3. Add corresponding buffer in `live_plotter.py`
4. Update CSV header in `data_logger.py`

### Custom Error Codes

Add new error codes to `ERROR_CODES` dictionary in `config.py`:

```python
ERROR_CODES: Dict[int, str] = {
    999: "Custom Error: Description here",
    # ...
}
```

## Best Practices

1. **Always close log files properly**: Use "Disconnect" before closing application
2. **Monitor watchdog alerts**: Indicates connection or equipment issues
3. **Regularly backup log files**: Prevent data loss
4. **Test with mock data first**: Verify system before hardware connection
5. **Review error logs**: Check for parse errors or validation issues

## Future Enhancements

Planned features:
- [ ] Real-time data export to other formats
- [ ] Advanced statistical analysis
- [ ] Remote monitoring capabilities
- [ ] Database integration
- [ ] Configurable alert thresholds
- [ ] Multi-device support

## Technical Notes

### Threading Model

- **SerialReader Thread**: Continuously reads from serial port
- **DataProcessor Thread**: Processes and validates incoming data
- **GUI Thread**: Handles user interface and plot updates
- **Watchdog Timer**: Monitors data flow in GUI thread

### Queue Management

Uses Python's `queue.Queue` for thread-safe data passing:
- Producer (SerialReader) → Queue → Consumer (DataProcessor)
- Prevents data loss during OS stalls

### Memory Management

- Uses `collections.deque` with maxlen for efficient ring buffers
- Automatic old data removal when buffer is full
- Minimal memory footprint for long-running tests

## License

This software is provided as-is for fatigue testing applications.

## Support

For issues or questions:
1. Check this README first
2. Review the status log for error messages
3. Test with mock data to isolate hardware vs. software issues
4. Verify serial port settings match equipment specifications

## Version History

### Version 1.0.0
- Initial release
- Core functionality: serial acquisition, logging, plotting
- Mock data generator for testing
- Watchdog timer implementation
- PyQt5 GUI with statistics display
