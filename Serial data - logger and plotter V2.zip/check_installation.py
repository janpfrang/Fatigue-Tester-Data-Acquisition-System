"""
Installation Checker and Troubleshooter
Run this script first to diagnose any issues
"""

import sys
import os
from pathlib import Path

print("=" * 70)
print("FATIGUE TESTER - INSTALLATION CHECKER")
print("=" * 70)
print()

# Check Python version
print("1. Checking Python version...")
version = sys.version_info
print(f"   Python {version.major}.{version.minor}.{version.micro}")
if version.major < 3 or (version.major == 3 and version.minor < 8):
    print("   ✗ ERROR: Python 3.8 or higher required!")
    sys.exit(1)
else:
    print("   ✓ OK")
print()

# Check current directory
print("2. Checking current directory...")
current_dir = Path.cwd()
print(f"   {current_dir}")
print()

# Check for required Python files
print("3. Checking for required Python files...")
required_files = [
    'main_application.py',
    'config.py',
    'data_parser.py',
    'serial_reader.py',
    'data_logger.py',
    'live_plotter.py',
    'requirements.txt'
]

missing_files = []
for filename in required_files:
    filepath = current_dir / filename
    if filepath.exists():
        print(f"   ✓ {filename}")
    else:
        print(f"   ✗ {filename} - MISSING!")
        missing_files.append(filename)
print()

if missing_files:
    print("ERROR: Missing files detected!")
    print()
    print("Missing files:")
    for f in missing_files:
        print(f"  - {f}")
    print()
    print("SOLUTION:")
    print("  1. Make sure all Python files are downloaded")
    print("  2. Put them all in the SAME directory")
    print("  3. Run this script again from that directory")
    print()
    input("Press Enter to exit...")
    sys.exit(1)

# Check for dependencies
print("4. Checking Python dependencies...")
dependencies = {
    'serial': 'pyserial',
    'PyQt5': 'PyQt5',
    'pyqtgraph': 'pyqtgraph',
    'pandas': 'pandas',
    'numpy': 'numpy'
}

missing_deps = []
for module, package in dependencies.items():
    try:
        __import__(module.split('.')[0])
        print(f"   ✓ {package}")
    except ImportError:
        print(f"   ✗ {package} - NOT INSTALLED!")
        missing_deps.append(package)
print()

if missing_deps:
    print("WARNING: Missing Python packages detected!")
    print()
    print("Missing packages:")
    for p in missing_deps:
        print(f"  - {p}")
    print()
    print("SOLUTION:")
    print("  Run this command to install missing packages:")
    print(f"  pip install {' '.join(missing_deps)}")
    print()
    print("  OR install all requirements:")
    print("  pip install -r requirements.txt")
    print()
    response = input("Do you want to continue anyway? (y/n): ")
    if response.lower() != 'y':
        sys.exit(1)
    print()

# Check logs directory
print("5. Checking logs directory...")
logs_dir = current_dir / 'logs'
if not logs_dir.exists():
    print(f"   Creating logs directory...")
    logs_dir.mkdir(exist_ok=True)
    print("   ✓ Created")
else:
    print("   ✓ Exists")
print()

# Try importing modules
print("6. Testing module imports...")
try:
    import config
    print("   ✓ config")
except Exception as e:
    print(f"   ✗ config - {e}")

try:
    import data_parser
    print("   ✓ data_parser")
except Exception as e:
    print(f"   ✗ data_parser - {e}")

try:
    import serial_reader
    print("   ✓ serial_reader")
except Exception as e:
    print(f"   ✗ serial_reader - {e}")

try:
    import data_logger
    print("   ✓ data_logger")
except Exception as e:
    print(f"   ✗ data_logger - {e}")

try:
    import live_plotter
    print("   ✓ live_plotter")
except Exception as e:
    print(f"   ✗ live_plotter - {e}")

print()

# Final check
print("=" * 70)
print("INSTALLATION CHECK COMPLETE")
print("=" * 70)
print()
print("If all checks passed, you can now run:")
print("  python main_application.py")
print()
print("For testing without hardware:")
print("  1. Run: python main_application.py")
print("  2. Check 'Use Mock Data (Testing)'")
print("  3. Click 'Connect'")
print()
input("Press Enter to exit...")
